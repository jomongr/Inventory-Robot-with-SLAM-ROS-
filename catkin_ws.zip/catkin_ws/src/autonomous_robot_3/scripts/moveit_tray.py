#!/usr/bin/env python

import sys
import rospy
import moveit_commander
import moveit_msgs.msg
import geometry_msgs.msg

def move_to_pose(pose_name):
    group.set_named_target(pose_name)
    plan = group.go(wait=True)
    group.stop()
    group.clear_pose_targets()

def main():
    moveit_commander.roscpp_initialize(sys.argv)
    rospy.init_node('move_group_interface', anonymous=True)

    global group
    group = moveit_commander.MoveGroupCommander("tray")  # Replace with your MoveIt group name

    rospy.sleep(2)

    print("Moving to idle pose")
    move_to_pose("idle")

    rospy.sleep(2)

    print("Moving to final pose")
    move_to_pose("final")

    moveit_commander.roscpp_shutdown()

if __name__ == '__main__':
    main()

